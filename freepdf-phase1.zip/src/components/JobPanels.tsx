import { useEffect, useMemo, useRef, useState } from 'react'
import type { Job } from './useJob'
import { Button, Notice } from './ui'
import { Icon } from './Icon'
import { formatBytes } from '../lib/files'
import { downloadBlob, zipOutputs, type OutputFile } from '../lib/output'

export function ProgressPanel({ job }: { job: Job }) {
  const pct = Math.round(job.progress * 100)
  return (
    <div className="fade-in rounded-2xl border border-line bg-surface p-6" role="status" aria-live="polite">
      <div className="mb-3 flex items-baseline justify-between gap-4">
        <p className="font-semibold">{job.label ?? 'Working…'}</p>
        <p className="font-display text-2xl font-semibold tabular-nums">{pct}%</p>
      </div>
      <div className="h-2.5 overflow-hidden rounded-full bg-surface-2" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct} aria-label="Progress">
        <div className="h-full rounded-full bg-accent transition-[width] duration-200" style={{ width: `${Math.max(3, pct)}%` }} />
      </div>
      <div className="mt-4 flex items-center justify-between">
        <p className="text-sm text-muted">Processing on your device. You can keep using this tab.</p>
        <Button variant="ghost" size="sm" onClick={job.cancel}>Cancel</Button>
      </div>
    </div>
  )
}

export function ResultPanel({ job, onStartOver, zipName = 'freepdf-files.zip' }: { job: Job; onStartOver: () => void; zipName?: string }) {
  const files = job.results
  const heading = useRef<HTMLHeadingElement>(null)
  const [zipping, setZipping] = useState(false)
  const total = useMemo(() => files.reduce((s, f) => s + f.blob.size, 0), [files])

  useEffect(() => { heading.current?.focus() }, [])

  const downloadAll = async () => {
    setZipping(true)
    try {
      downloadBlob(await zipOutputs(files), zipName)
    } finally {
      setZipping(false)
    }
  }

  return (
    <section className="fade-in rounded-2xl border border-line bg-surface p-6" aria-labelledby="result-h">
      <div className="flex flex-wrap items-center gap-4">
        <span className="grid h-12 w-12 place-items-center rounded-full bg-ok-soft text-ok"><Icon name="check" size={26} strokeWidth={2.4} /></span>
        <div className="min-w-0 flex-1">
          <h2 id="result-h" ref={heading} tabIndex={-1} className="text-2xl font-bold">
            {files.length === 1 ? 'Your file is ready' : `${files.length} files are ready`}
          </h2>
          <p className="text-muted">{job.summary ?? `${formatBytes(total)} total`}</p>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        {files.length === 1 ? (
          <Button variant="primary" size="lg" icon="download" onClick={() => downloadBlob(files[0].blob, files[0].name)} data-testid="download">
            Download
          </Button>
        ) : (
          <Button variant="primary" size="lg" icon="zip" onClick={downloadAll} disabled={zipping} data-testid="download-zip">
            {zipping ? 'Preparing ZIP…' : 'Download all (ZIP)'}
          </Button>
        )}
        <Button size="lg" icon="refresh" onClick={onStartOver} data-testid="start-over">Start over</Button>
      </div>

      {files.length > 1 && <OutputList files={files} />}
      {files.length === 1 && files[0].note && !job.summary && <p className="mt-4 text-sm text-muted">{files[0].note}</p>}

      <p className="mt-6 border-t border-line pt-4 text-sm text-muted">
        These files only exist in this tab. “Start over” or closing the tab removes them from memory.
      </p>
    </section>
  )
}

function OutputList({ files }: { files: OutputFile[] }) {
  return (
    <ul className="mt-6 max-h-96 divide-y divide-line overflow-auto rounded-xl border border-line" aria-label="Output files">
      {files.map((f, i) => (
        <li key={i} className="flex items-center gap-3 px-4 py-2.5">
          <Icon name="file" size={18} className="shrink-0 text-muted" />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[15px] font-semibold">{f.name}</span>
            <span className="block text-sm text-muted">{formatBytes(f.blob.size)}{f.note ? ` · ${f.note}` : ''}</span>
          </span>
          <Button variant="ghost" size="sm" icon="download" onClick={() => downloadBlob(f.blob, f.name)} aria-label={`Download ${f.name}`}>
            <span className="hidden sm:inline">Download</span>
          </Button>
        </li>
      ))}
    </ul>
  )
}

/** Renders progress / error / result for a job; returns null while idle. */
export function JobStatus({ job, onStartOver, zipName }: { job: Job; onStartOver: () => void; zipName?: string }) {
  if (job.status === 'running') return <ProgressPanel job={job} />
  if (job.status === 'done') return <ResultPanel job={job} onStartOver={onStartOver} zipName={zipName} />
  if (job.status === 'error') return <Notice tone="error">{job.error}</Notice>
  return null
}
